exports.types = {
  webp: { sharp: 'webp', contentType: 'image/webp'},
  jpeg: { sharp: 'jpeg', contentType: 'image/jpeg'},
  png: { sharp: 'png', contentType: 'image/png'},
};
